# Spring Build Git Submodule

The Bundlor project uses a Git submodule to include the `spring-build` engine
for building.  To get this submodule, run the following commands after cloning
the repository.

> git submodule init
> git submodule update
