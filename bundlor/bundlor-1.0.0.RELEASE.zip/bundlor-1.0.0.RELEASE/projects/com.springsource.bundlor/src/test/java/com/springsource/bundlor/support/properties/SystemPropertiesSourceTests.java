/*
 * Copyright 2008-2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support.properties;

import static org.junit.Assert.assertEquals;

import java.util.Properties;

import org.junit.Test;

public class SystemPropertiesSourceTests {

    private SystemPropertiesSource propertiesSource = new SystemPropertiesSource();

    @Test
    public void properties() {
        Properties props = propertiesSource.getProperties();
        for (Object key : System.getProperties().keySet()) {
            assertEquals(System.getProperty((String) key), props.getProperty((String) key));
        }
    }

    @Test
    public void priority() {
        assertEquals(Integer.MIN_VALUE, propertiesSource.getPriority());
    }

}
