#!/bin/bash

rm -rf target
mkdir target

../../../bin/bundlor.sh \
	-i ./org.springframework.integration.jar \
	-m ./template.mf \
	-o ./target/org.springframework.integration.jar
