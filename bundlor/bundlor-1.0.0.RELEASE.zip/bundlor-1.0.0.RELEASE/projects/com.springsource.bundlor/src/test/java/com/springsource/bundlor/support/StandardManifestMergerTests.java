/*
 * Copyright 2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Arrays;

import org.junit.Test;

import com.springsource.bundlor.support.partialmanifest.ReadablePartialManifest;
import com.springsource.bundlor.support.partialmanifest.StandardReadablePartialManifest;
import com.springsource.bundlor.util.SimpleManifestContents;
import com.springsource.util.osgi.manifest.BundleManifest;
import com.springsource.util.osgi.manifest.BundleManifestFactory;
import com.springsource.util.parser.manifest.ManifestContents;

public class StandardManifestMergerTests {

    private final StandardManifestMerger merger = new StandardManifestMerger(new StubPartialManifestResolver());

    @Test
    public void merge() {
        ManifestContents existingManifest = new SimpleManifestContents();
        existingManifest.getMainAttributes().put("existing-key", "existing-value");
        existingManifest.getMainAttributes().put("template-key", "existing-value");
        existingManifest.getMainAttributes().put("resolved-key", "existing-value");
        existingManifest.getMainAttributes().put("removed-key", "existing-value");

        ManifestContents templateManifest = new SimpleManifestContents();
        templateManifest.getMainAttributes().put("template-key", "template-value");
        templateManifest.getMainAttributes().put("resolved-key", "template-value");

        ManifestContents manifest = this.merger.merge(existingManifest, templateManifest, new SimpleManifestContents(),
            new StandardReadablePartialManifest(), Arrays.asList("removed-key"));

        assertEquals("existing-value", manifest.getMainAttributes().get("existing-key"));
        assertEquals("template-value", manifest.getMainAttributes().get("template-key"));
        assertEquals("resolved-value", manifest.getMainAttributes().get("resolved-key"));
        assertNull(manifest.getMainAttributes().get("removed-key"));
    }

    private static class StubPartialManifestResolver implements PartialManifestResolver {

        public BundleManifest resolve(ManifestContents templateManifest, ReadablePartialManifest partial) {
            BundleManifest manifest = BundleManifestFactory.createBundleManifest();
            manifest.setHeader("resolved-key", "resolved-value");
            return manifest;
        }

    }
}
