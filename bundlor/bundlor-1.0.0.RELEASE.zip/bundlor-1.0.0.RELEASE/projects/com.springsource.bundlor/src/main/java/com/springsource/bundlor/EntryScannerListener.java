/*
 * Copyright 2008-2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor;

/**
 * Lifecycle interface to be implemented by interested parties to get notified during scanning of JARs or class folders
 * with start and end events on a per entry/file basis.
 * 
 * @author Christian Dupuis
 */
public interface EntryScannerListener {

    /**
     * Start scanning of entry identified by given <code>name</code>.
     */
    void onBeginEntry(String name);

    /**
     * End scanning of latest started entry.
     */
    void onEndEntry();
}
