/*
 * Copyright 2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.maven.plugin.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public final class Configuration {

    private volatile String inputPath;

    private volatile String outputPath;

    private volatile String manifestTemplatePath;

    private volatile String manifestTemplate;

    private volatile String osgiProfilePath;

    private volatile String osgiProfile;

    private volatile String bundleSymbolicName;

    private volatile String defaultBundleSymbolicName;

    private volatile String bundleVersion;

    private volatile String defaultBundleVersion;

    private volatile String propertiesPath;

    private final List<Properties> properties = new ArrayList<Properties>();

    public void setInputPath(String inputPath) {
        this.inputPath = inputPath;
    }

    public void setOutputPath(String outputPath) {
        this.outputPath = outputPath;
    }

    public void setManifestTemplatePath(String manifestTemplatePath) {
        this.manifestTemplatePath = manifestTemplatePath;
    }

    public void setManifestTemplate(String manifestTemplate) {
        this.manifestTemplate = manifestTemplate;
    }

    public void setOsgiProfilePath(String osgiProfilePath) {
        this.osgiProfilePath = osgiProfilePath;
    }

    public void setOsgiProfile(String osgiProfile) {
        this.osgiProfile = osgiProfile;
    }

    public void setBundleSymbolicName(String bundleSymbolicName) {
        this.bundleSymbolicName = bundleSymbolicName;
    }

    public void setDefaultBundleSymbolicName(String defaultBundleSymbolicName) {
        this.defaultBundleSymbolicName = defaultBundleSymbolicName;
    }

    public void setBundleVersion(String bundleVersion) {
        this.bundleVersion = bundleVersion;
    }

    public void setDefaultBundleVersion(String defaultBundleVersion) {
        this.defaultBundleVersion = defaultBundleVersion;
    }

    public void setPropertiesPath(String propertiesPath) {
        this.propertiesPath = propertiesPath;
    }

    public void addProperties(Properties properties) {
        this.properties.add(properties);
    }

    public String getInputPath() {
        return inputPath;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public String getManifestTemplatePath() {
        return manifestTemplatePath;
    }

    public String getManifestTemplate() {
        return manifestTemplate;
    }

    public String getOsgiProfilePath() {
        return osgiProfilePath;
    }

    public String getOsgiProfile() {
        return osgiProfile;
    }

    public String getBundleSymbolicName() {
        return bundleSymbolicName;
    }

    public String getDefaultBundleSymbolicName() {
        return defaultBundleSymbolicName;
    }

    public String getBundleVersion() {
        return bundleVersion;
    }

    public String getDefaultBundleVersion() {
        return defaultBundleVersion;
    }

    public String getPropertiesPath() {
        return propertiesPath;
    }

    public List<Properties> getProperties() {
        return properties;
    }

}
