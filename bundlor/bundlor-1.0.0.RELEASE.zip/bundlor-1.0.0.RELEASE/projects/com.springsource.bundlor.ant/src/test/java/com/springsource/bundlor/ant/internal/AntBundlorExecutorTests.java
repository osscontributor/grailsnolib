/*
 * Copyright 2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.ant.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.taskdefs.Property;
import org.apache.tools.ant.types.PropertySet;
import org.junit.Test;

import com.springsource.bundlor.ClassPath;
import com.springsource.bundlor.ClassPathEntry;
import com.springsource.bundlor.ManifestWriter;
import com.springsource.bundlor.support.classpath.ClassPathFactory;
import com.springsource.bundlor.support.manifestwriter.ManifestWriterFactory;
import com.springsource.bundlor.support.properties.EmptyPropertiesSource;
import com.springsource.bundlor.support.properties.PropertiesSource;
import com.springsource.bundlor.util.SimpleManifestContents;
import com.springsource.util.parser.manifest.ManifestContents;

public class AntBundlorExecutorTests {

    @Test
    public void execute() {
        new AntBundlorExecutor(new Configuration(), new StubConfigurationValidator(), new StubClassPathFactory(), new StubManifestWriterFactory(),
            new StubManifestTemplateFactory(), new StubPropertiesSourceFactory(), new StubOsgiProfileFactory()).execute();
    }

    private static class StubConfigurationValidator implements ConfigurationValidator {

        public void validate(Configuration configuration) throws BuildException {
        }

    }

    private static class StubClassPathFactory implements ClassPathFactory {

        public ClassPath create(String inputPath) {
            return new StubClassPath();
        }

    }

    private static class StubClassPath implements ClassPath {

        public ClassPathEntry getEntry(String name) {
            return null;
        }

        public Iterator<ClassPathEntry> iterator() {
            return new Iterator<ClassPathEntry>() {

                public boolean hasNext() {
                    return false;
                }

                public ClassPathEntry next() {
                    return null;
                }

                public void remove() {
                }

            };
        }

        public void close() {
        }
    }

    private static class StubManifestWriterFactory implements ManifestWriterFactory {

        public ManifestWriter create(String inputPath, String outputPath) {
            return new StubManifestWriter();
        }

    }

    private static class StubManifestWriter implements ManifestWriter {

        public void write(ManifestContents manifest) {
        }

        public void close() {
        }

    }

    private static class StubManifestTemplateFactory implements ManifestTemplateFactory {

        public ManifestContents create(String manifestTemplatePath, String manifestTemplate, String bundleSymbolicName, String bundleVersion) {
            return new SimpleManifestContents();
        }

    }

    private static class StubPropertiesSourceFactory implements PropertiesSourceFactory {

        public List<PropertiesSource> create(String propertiesPath, List<PropertySet> propertySets, List<Property> properties) {
            return new ArrayList<PropertiesSource>();
        }

    }

    private static class StubOsgiProfileFactory implements OsgiProfileFactory {

        public PropertiesSource create(String osgiProfilePath, String osgiProfile) {
            return new EmptyPropertiesSource();
        }

    }

}
