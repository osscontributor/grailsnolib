/*
 * Copyright 2008-2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.springsource.bundlor.util.MatchUtils;

public class MatchUtilsTests {

    @Test
    public void matchWildcard() {
        assertTrue(MatchUtils.matches("com.foo.bar", "com.foo.bar.*"));
        assertTrue(MatchUtils.matches("com.foo.bar", "com.foo.bar"));
        assertTrue(MatchUtils.matches("com.foo.bar", "com.foo.*"));
        assertTrue(MatchUtils.matches("com.foo.bar", "*"));
        assertFalse(MatchUtils.matches("com.foo.bar", "com.foo"));
        assertFalse(MatchUtils.matches("javax.foo", "java.*"));
    }

    @Test
    public void matchMultipleWildcards() {
        // multiple wildcards matches
        assertTrue(MatchUtils.matches("com.foo.internal.bar", "*.internal.*"));
        assertTrue(MatchUtils.matches("com.foo.internal.bar", "*internal*"));
        assertTrue(MatchUtils.matches("com.foo.internal.bar", "com.foo.*internal.*"));
        assertFalse(MatchUtils.matches("com.foo.internal.bar", "com.foo.*internal"));
        assertTrue(MatchUtils.matches("com.foo.internal.bar", "com.*.*internal.*"));
        assertFalse(MatchUtils.matches("com.foo.internal.bar", "com.*.*.internal.*"));
        assertTrue(MatchUtils.matches("com.foo.internal.bar", "*.*.internal.*"));
    }

    @Test
    public void matchWithUnderscoreInPackageName() {
        assertTrue(MatchUtils.matches("com_cenqua_clover", "com_cenqua_clover"));
        assertTrue(MatchUtils.matches("com_cenqua_clover", "com_cenqua_clover.*"));
        assertTrue(MatchUtils.matches("com_cenqua_clover", "com_cenqua_clover*"));
        assertTrue(MatchUtils.matches("com_cenqua_clover", "com_cenqua*"));
        assertTrue(MatchUtils.matches("com_cenqua_clover", "com*"));
    }

    @Test
    public void testRankedMatch() {
        assertEquals(MatchUtils.NO_MATCH, MatchUtils.rankedMatch("", null));
        assertEquals(MatchUtils.NO_MATCH, MatchUtils.rankedMatch("", ""));
        assertEquals(MatchUtils.NO_MATCH, MatchUtils.rankedMatch("com.foo.bar", "foo.*"));
        assertEquals(0, MatchUtils.rankedMatch("", "*"));

        int rank1 = MatchUtils.rankedMatch("com.foo.bar.Fudge", "com.foo.*");
        int rank2 = MatchUtils.rankedMatch("com.foo.bar.Fudge", "com.foo.bar.*");
        assertTrue(rank1 < rank2);
    }

}
