/*
 * Copyright 2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support.contributors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Test;

import com.springsource.bundlor.support.partialmanifest.ReadablePartialManifest;
import com.springsource.bundlor.support.partialmanifest.StandardReadablePartialManifest;

public class StaticResourceArtefactAnalyserTests {

    private final StaticResourceArtefactAnalyser analyzer = new StaticResourceArtefactAnalyser();

    @Test
    public void analyze() throws Exception {
        ReadablePartialManifest partialManifest = new StandardReadablePartialManifest();

        this.analyzer.analyse(null, "com/test.properties", partialManifest);
        this.analyzer.analyse(null, "com/springsource/test.properties", partialManifest);
        this.analyzer.analyse(null, "com/springsource/test/test.properties", partialManifest);
        
        Set<String> exportedPackages = partialManifest.getExportedPackages();
        assertEquals(3, exportedPackages.size());
        assertTrue(exportedPackages.contains("com"));
        assertTrue(exportedPackages.contains("com.springsource"));
        assertTrue(exportedPackages.contains("com.springsource.test"));
    }

    @Test
    public void canAnalyse() {
        assertTrue(this.analyzer.canAnalyse("test.properties"));
        assertFalse(this.analyzer.canAnalyse("META-INF/MANIFEST.MF"));
        assertFalse(this.analyzer.canAnalyse("WEB-INF/index.html"));
        assertFalse(this.analyzer.canAnalyse("test.class"));
        assertFalse(this.analyzer.canAnalyse(".DS_Store"));
    }
}
