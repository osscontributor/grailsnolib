/*
 * Copyright 2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support.contributors;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Set;

import org.junit.Test;

import com.springsource.bundlor.support.partialmanifest.StandardReadablePartialManifest;

public class SpringApplicationContextArtefactAnalyserTests {

    private final SpringApplicationContextArtefactAnalyser analyzer = new SpringApplicationContextArtefactAnalyser();

    @Test
    public void analyze() throws Exception {
        InputStream in = null;
        try {
            in = new FileInputStream("src/test/resources/com/springsource/bundlor/support/contributors/spring-1.xml");
            StandardReadablePartialManifest manifest = new StandardReadablePartialManifest();
            this.analyzer.analyse(in, "test-artifact", manifest);

            assertContains("org.springframework.somebean", manifest.getImportedPackages());
            assertContains("org.springframework.somebean2", manifest.getImportedPackages());
            assertContains("org.springframework.somebean4", manifest.getImportedPackages());

             assertContains("xml.org.springframework.aop.implementinterface", manifest.getImportedPackages());
             assertContains("xml.org.springframework.aop.defaultimpl", manifest.getImportedPackages());
             assertContains("xml.org.springframework.context.basepackage", manifest.getImportedPackages());
             assertContains("xml.org.springframework.context.namegenerator", manifest.getImportedPackages());
             assertContains("xml.org.springframework.context.scoperesolver", manifest.getImportedPackages());
             assertContains("xml.org.springframework.context.loadtimeweaver", manifest.getImportedPackages());
             assertContains("xml.org.springframework.jee.jndilookup.expectedtype", manifest.getImportedPackages());
             assertContains("xml.org.springframework.jee.jndilookup.proxyinteface", manifest.getImportedPackages());
             assertContains("xml.org.springframework.jee.localslsb.businessinterface", manifest.getImportedPackages());
             assertContains("xml.org.springframework.jee.remoteslsb.businessinterface", manifest.getImportedPackages());
             assertContains("xml.org.springframework.jee.remoteslsb.homeinterface", manifest.getImportedPackages());
             assertContains("xml.org.springframework.jms.listenercontainer.containerclass", manifest.getImportedPackages());
             assertContains("xml.org.springframework.jruby.scripinterfaces.a", manifest.getImportedPackages());
             assertContains("xml.org.springframework.jruby.scripinterfaces.b", manifest.getImportedPackages());
             assertContains("xml.org.springframework.bsh.scripinterfaces.a", manifest.getImportedPackages());
             assertContains("xml.org.springframework.bsh.scripinterfaces.b", manifest.getImportedPackages());
             assertContains("xml.org.springframework.osgi.reference.interface", manifest.getImportedPackages());
             assertContains("xml.org.springframework.osgi.reference.interface.b", manifest.getImportedPackages());
             assertContains("xml.org.springframework.osgi.reference.interface.c", manifest.getImportedPackages());
             assertContains("xml.org.springframework.osgi.service.interface", manifest.getImportedPackages());
             assertContains("xml.org.springframework.osgi.service.interface.b", manifest.getImportedPackages());
             assertContains("xml.org.springframework.osgi.service.interface.c", manifest.getImportedPackages());
             assertContains("xml.org.springframework.util.list.listclass", manifest.getImportedPackages());
             assertContains("xml.org.springframework.util.map.mapclass", manifest.getImportedPackages());
             assertContains("xml.org.springframework.util.set.setclass", manifest.getImportedPackages());
        } finally {
            if (in != null) {
                in.close();
            }
        }
    }

    @Test
    public void canAnalyze() {
        assertTrue(this.analyzer.canAnalyse("test.xml"));
        assertFalse(this.analyzer.canAnalyse("test.properties"));
    }

    private void assertContains(String expected, Set<String> importedPackages) {
        for (String importedPackage : importedPackages) {
            if (expected.equals(importedPackage)) {
                return;
            }
        }
        fail("Expected imported packages to contain " + expected);
    }
}
