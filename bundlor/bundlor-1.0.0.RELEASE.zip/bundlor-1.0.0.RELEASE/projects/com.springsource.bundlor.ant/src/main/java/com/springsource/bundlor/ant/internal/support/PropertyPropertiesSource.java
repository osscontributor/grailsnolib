/*
 * Copyright 2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.ant.internal.support;

import java.util.List;
import java.util.Properties;

import org.apache.tools.ant.taskdefs.Property;
import org.apache.tools.ant.types.PropertySet;

import com.springsource.bundlor.support.properties.PropertiesPropertiesSource;
import com.springsource.bundlor.support.properties.PropertiesSource;

public class PropertyPropertiesSource implements PropertiesSource {

    private final Properties properties;

    /**
     * Create a new {@link PropertiesPropertiesSource} with the given {@link Property}s.
     * 
     * @param propertySets list of {@link PropertySet}s
     */
    public PropertyPropertiesSource(List<Property> properties) {
        this.properties = new Properties();
        for (Property property : properties) {
            this.properties.put(property.getName(), property.getValue());
        }
    }

    /**
     * {@inheritDoc}
     */
    public int getPriority() {
        return Integer.MAX_VALUE;
    }

    /**
     * {@inheritDoc}
     */
    public Properties getProperties() {
        return properties;
    }
}
