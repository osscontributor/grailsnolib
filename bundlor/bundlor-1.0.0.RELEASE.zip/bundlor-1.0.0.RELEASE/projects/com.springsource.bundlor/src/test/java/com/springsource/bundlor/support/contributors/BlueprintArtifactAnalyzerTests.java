/*
 * Copyright 2008-2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support.contributors;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Set;

import org.junit.Test;

import com.springsource.bundlor.support.partialmanifest.StandardReadablePartialManifest;
import com.springsource.bundlor.util.SimpleManifestContents;
import com.springsource.util.parser.manifest.ManifestContents;

public class BlueprintArtifactAnalyzerTests {

    private final BlueprintArtifactAnalyzer analyzer = new BlueprintArtifactAnalyzer();

    @Test
    public void analyze() throws Exception {
        InputStream in = null;
        try {
            in = new FileInputStream("src/test/resources/com/springsource/bundlor/support/contributors/blueprint-1.xml");
            StandardReadablePartialManifest manifest = new StandardReadablePartialManifest();
            this.analyzer.analyse(in, "test-artifact", manifest);

            assertContains("beans1", manifest.getImportedPackages());
            assertContains("beans2", manifest.getImportedPackages());
            assertContains("service1", manifest.getImportedPackages());
            assertContains("service2", manifest.getImportedPackages());
            assertContains("reference1", manifest.getImportedPackages());
            assertContains("reference2", manifest.getImportedPackages());
            assertContains("referenceList1", manifest.getImportedPackages());
            assertContains("referenceList2", manifest.getImportedPackages());
            assertContains("interfaces1", manifest.getImportedPackages());
            assertContains("interfaces2", manifest.getImportedPackages());
        } finally {
            if (in != null) {
                in.close();
            }
        }

    }

    @Test
    public void defaultContextLocation() {
        this.analyzer.readJarManifest(new SimpleManifestContents());
        assertTrue(this.analyzer.canAnalyse("OSGI-INF/blueprint/test.xml"));
        assertFalse(this.analyzer.canAnalyse("META-INF/test.xml"));
    }

    @Test
    public void customContextLocation() {
        ManifestContents manifest = new SimpleManifestContents();
        manifest.getMainAttributes().put("Bundle-Blueprint", "META-INF/test.xml");
        this.analyzer.readJarManifest(manifest);

        assertTrue(this.analyzer.canAnalyse("META-INF/test.xml"));
        assertFalse(this.analyzer.canAnalyse("OSGI-INF/blueprint/test.xml"));
    }

    private void assertContains(String expected, Set<String> importedPackages) {
        for (String importedPackage : importedPackages) {
            if (expected.equals(importedPackage)) {
                return;
            }
        }
        fail("Expected imported packages to contain " + expected);
    }

}
